module.exports = {
  content: ["./index.html", "./js/**/*.js"],
  theme: {
    extend: {
      colors: {
        ink: "#0E0E10",
        surface: "#16161A",
        surface2: "#1E1E23",
        ember: "#FF4D23",
        emberDark: "#E03A12",
        gold: "#D4AF37",
        stone: "#9A9FA8",
        paper: "#F4F2EE"
      },
      fontFamily: {
        display: ["Anton", "Impact", "sans-serif"],
        body: ["Inter", "system-ui", "sans-serif"]
      }
    }
  }
};
