const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

document.addEventListener("DOMContentLoaded", () => {
  setYear();
  initHeader();
  initMobileMenu();
  initScrollSpy();
  initReveal();
  initStatsCounter();
  initCardSpotlight();
  initBillingToggle();
  initPlanLinks();
  initTestimonialSlider();
  initFaqAccordion();
  initScrollTop();
  initContactForm();
});

function setYear() {
  const el = document.getElementById("year");
  if (el) el.textContent = new Date().getFullYear();
}

function initHeader() {
  const header = document.getElementById("siteHeader");
  const progress = document.getElementById("scrollProgress");
  let ticking = false;

  const update = () => {
    const y = window.scrollY;
    const max = document.documentElement.scrollHeight - window.innerHeight;
    header.classList.toggle("scrolled", y > 40);
    progress.style.transform = `scaleX(${max > 0 ? Math.min(y / max, 1) : 0})`;
    ticking = false;
  };

  window.addEventListener("scroll", () => {
    if (!ticking) {
      ticking = true;
      requestAnimationFrame(update);
    }
  }, { passive: true });
  window.addEventListener("resize", update);
  update();
}

function initMobileMenu() {
  const toggle = document.getElementById("menuToggle");
  const menu = document.getElementById("mobileMenu");
  const header = document.getElementById("siteHeader");
  const links = menu.querySelectorAll("a");

  const setOpen = (open) => {
    menu.classList.toggle("open", open);
    header.classList.toggle("menu-active", open);
    toggle.classList.toggle("menu-open", open);
    document.body.style.overflow = open ? "hidden" : "";
    toggle.setAttribute("aria-expanded", String(open));
    toggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
    menu.setAttribute("aria-hidden", String(!open));
  };

  toggle.addEventListener("click", () => setOpen(!menu.classList.contains("open")));
  links.forEach((link) => link.addEventListener("click", () => setOpen(false)));

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && menu.classList.contains("open")) {
      setOpen(false);
      toggle.focus();
    }
  });

  window.matchMedia("(min-width: 1024px)").addEventListener("change", (e) => {
    if (e.matches) setOpen(false);
  });
}

function initScrollSpy() {
  const sections = [...document.querySelectorAll("main section[id]")];
  const links = document.querySelectorAll(".nav-link, .mobile-nav-link:not(.mobile-nav-link-cta)");
  if (!sections.length) return;

  const setActive = (id) => {
    links.forEach((link) => link.classList.toggle("active", link.getAttribute("href") === `#${id}`));
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) setActive(entry.target.id);
    });
  }, { rootMargin: "-40% 0px -55% 0px", threshold: 0 });

  sections.forEach((section) => observer.observe(section));
}

function initReveal() {
  const items = document.querySelectorAll("[data-reveal]");
  if (!items.length) return;

  if (reducedMotion || !("IntersectionObserver" in window)) {
    items.forEach((el) => el.classList.add("in-view"));
    return;
  }

  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("in-view");
        obs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });

  items.forEach((el) => observer.observe(el));
}

function initStatsCounter() {
  const counters = document.querySelectorAll(".stat-num");
  if (!counters.length) return;

  const format = (el, value) => {
    const decimals = parseInt(el.dataset.decimals || "0", 10);
    el.textContent = value.toFixed(decimals);
  };

  const animate = (el) => {
    const target = parseFloat(el.dataset.target);
    if (reducedMotion) {
      format(el, target);
      return;
    }
    const duration = 1600;
    const start = performance.now();
    const tick = (now) => {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 4);
      format(el, eased * target);
      if (progress < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  };

  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        animate(entry.target);
        obs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.6 });

  counters.forEach((el) => observer.observe(el));
}

function initCardSpotlight() {
  document.querySelectorAll(".program-card").forEach((card) => {
    card.addEventListener("pointermove", (e) => {
      const rect = card.getBoundingClientRect();
      card.style.setProperty("--x", `${e.clientX - rect.left}px`);
      card.style.setProperty("--y", `${e.clientY - rect.top}px`);
    });
  });
}

function initBillingToggle() {
  const monthlyBtn = document.getElementById("billMonthly");
  const yearlyBtn = document.getElementById("billYearly");
  const prices = document.querySelectorAll(".price");
  const suffixes = document.querySelectorAll(".price-suffix");
  const notes = document.querySelectorAll(".price-note");

  const formatPKR = (n) => "PKR " + n.toLocaleString("en-US");

  const setBilling = (period) => {
    const yearly = period === "yearly";
    monthlyBtn.classList.toggle("active", !yearly);
    yearlyBtn.classList.toggle("active", yearly);
    monthlyBtn.setAttribute("aria-pressed", String(!yearly));
    yearlyBtn.setAttribute("aria-pressed", String(yearly));

    prices.forEach((el) => {
      el.classList.add("swap");
      setTimeout(() => {
        const value = yearly
          ? Math.round(parseInt(el.dataset.yearly, 10) / 12)
          : parseInt(el.dataset.monthly, 10);
        el.textContent = formatPKR(value);
        el.classList.remove("swap");
      }, reducedMotion ? 0 : 160);
    });

    suffixes.forEach((el) => { el.textContent = "/month"; });
    notes.forEach((el) => { el.textContent = yearly ? el.dataset.yearlyNote : ""; });
  };

  monthlyBtn.addEventListener("click", () => setBilling("monthly"));
  yearlyBtn.addEventListener("click", () => setBilling("yearly"));
}

function initPlanLinks() {
  const select = document.getElementById("plan");
  document.querySelectorAll("[data-plan]").forEach((link) => {
    link.addEventListener("click", () => { select.value = link.dataset.plan; });
  });
}

function initTestimonialSlider() {
  const track = document.getElementById("testimonialTrack");
  const prevBtn = document.getElementById("testiPrev");
  const nextBtn = document.getElementById("testiNext");
  const dotsWrap = document.getElementById("testiDots");
  const region = track.closest(".slider");
  const slides = [...track.children];
  const total = slides.length;
  const AUTOPLAY_MS = 6500;

  let index = 0;
  let timer = null;
  let paused = false;

  const dots = slides.map((_, i) => {
    const dot = document.createElement("button");
    dot.type = "button";
    dot.className = "testi-dot";
    dot.setAttribute("role", "tab");
    dot.setAttribute("aria-label", `Show testimonial ${i + 1}`);
    dot.addEventListener("click", () => { goTo(i); restart(); });
    dotsWrap.appendChild(dot);
    return dot;
  });

  function goTo(i) {
    index = (i + total) % total;
    track.style.transform = `translateX(-${index * 100}%)`;
    slides.forEach((slide, si) => {
      const active = si === index;
      slide.setAttribute("aria-hidden", String(!active));
      slide.style.opacity = active ? "1" : "0";
      if (active) slide.removeAttribute("inert");
      else slide.setAttribute("inert", "");
    });
    dots.forEach((dot, di) => {
      const active = di === index;
      dot.classList.toggle("active", active);
      dot.setAttribute("aria-selected", String(active));
    });
  }

  function stop() {
    clearInterval(timer);
    timer = null;
  }

  function restart() {
    stop();
    if (!reducedMotion && !paused) timer = setInterval(() => goTo(index + 1), AUTOPLAY_MS);
  }

  prevBtn.addEventListener("click", () => { goTo(index - 1); restart(); });
  nextBtn.addEventListener("click", () => { goTo(index + 1); restart(); });

  region.addEventListener("mouseenter", () => { paused = true; stop(); });
  region.addEventListener("mouseleave", () => { paused = false; restart(); });
  region.addEventListener("focusin", () => { paused = true; stop(); });
  region.addEventListener("focusout", () => { paused = false; restart(); });

  region.addEventListener("keydown", (e) => {
    if (e.key === "ArrowLeft") { goTo(index - 1); restart(); }
    if (e.key === "ArrowRight") { goTo(index + 1); restart(); }
  });

  let startX = 0;
  let startY = 0;
  region.addEventListener("touchstart", (e) => {
    startX = e.touches[0].clientX;
    startY = e.touches[0].clientY;
  }, { passive: true });
  region.addEventListener("touchend", (e) => {
    const dx = e.changedTouches[0].clientX - startX;
    const dy = e.changedTouches[0].clientY - startY;
    if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy)) {
      goTo(dx < 0 ? index + 1 : index - 1);
      restart();
    }
  }, { passive: true });

  document.addEventListener("visibilitychange", () => {
    if (document.hidden) stop();
    else restart();
  });

  goTo(0);
  restart();
}

function initFaqAccordion() {
  const items = document.querySelectorAll(".faq-item");

  const setOpen = (item, open) => {
    item.classList.toggle("open", open);
    item.querySelector(".faq-question").setAttribute("aria-expanded", String(open));
  };

  items.forEach((item) => {
    item.querySelector(".faq-question").addEventListener("click", () => {
      const willOpen = !item.classList.contains("open");
      items.forEach((other) => setOpen(other, false));
      setOpen(item, willOpen);
    });
  });
}

function initScrollTop() {
  const btn = document.getElementById("scrollTop");
  window.addEventListener("scroll", () => {
    btn.classList.toggle("visible", window.scrollY > 700);
  }, { passive: true });
  btn.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: reducedMotion ? "auto" : "smooth" });
  });
}

function initContactForm() {
  const form = document.getElementById("contactForm");
  const submitBtn = document.getElementById("submitBtn");
  const label = submitBtn.querySelector(".btn-label");
  const success = document.getElementById("formSuccess");

  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const phonePattern = /^[+\d][\d\s\-()]{6,}$/;

  const rules = [
    { id: "name", test: (v) => v.trim().length >= 2, message: "Please enter your full name." },
    { id: "email", test: (v) => emailPattern.test(v.trim()), message: "Please enter a valid email address." },
    { id: "phone", test: (v) => v.trim() === "" || phonePattern.test(v.trim()), message: "Please enter a valid phone number." },
    { id: "message", test: (v) => v.trim().length >= 10, message: "Please write at least 10 characters." }
  ];

  const setError = (input, message) => {
    const error = document.getElementById(`${input.id}Error`);
    input.setAttribute("aria-invalid", message ? "true" : "false");
    error.textContent = message;
  };

  const validate = (rule) => {
    const input = document.getElementById(rule.id);
    const valid = rule.test(input.value);
    setError(input, valid ? "" : rule.message);
    return valid;
  };

  rules.forEach((rule) => {
    const input = document.getElementById(rule.id);
    input.addEventListener("blur", () => { if (input.value) validate(rule); });
    input.addEventListener("input", () => {
      if (input.getAttribute("aria-invalid") === "true") validate(rule);
    });
  });

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    success.classList.add("hidden");

    const results = rules.map(validate);
    if (results.includes(false)) {
      const firstInvalid = rules.find((rule, i) => !results[i]);
      document.getElementById(firstInvalid.id).focus();
      return;
    }

    submitBtn.disabled = true;
    label.textContent = "Sending...";

    setTimeout(() => {
      form.reset();
      rules.forEach((rule) => setError(document.getElementById(rule.id), ""));
      submitBtn.disabled = false;
      label.textContent = "Request a Free Trial";
      success.classList.remove("hidden");
      success.focus();
    }, 1000);
  });
}
